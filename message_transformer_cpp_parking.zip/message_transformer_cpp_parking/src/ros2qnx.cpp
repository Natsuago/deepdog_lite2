#include <geometry_msgs/Twist.h>
#include <std_msgs/Float64.h>
#include <std_msgs/Float64MultiArray.h>
#include <ros/ros.h>
#include <stdlib.h>

#include <ctime>

#include "input.h"

using namespace std;

boost::shared_ptr<InputSocket> input_;

// 设定为 4 字节对齐
#pragma pack(4)
struct DataSend {
  int32_t code;
  int32_t size;
  int32_t cons_code;
  double cmd_data;
};

struct DataSend2 {
  int32_t code;
  int32_t size;
  int32_t cons_code;
  double cmd_data1;
  double cmd_data2;
  double cmd_data3;
};

DataSend data;
DataSend data1;
DataSend2 data_barrier;

void ultrasound_callback(std_msgs::Float64 msg) {
  data1.code = 324;
  data1.size = 8;
  data1.cons_code = 1;
  data1.cmd_data = msg.data;
  input_->sendPacket((uint8_t*)&data1, sizeof(data1));
}


void vel_callback(geometry_msgs::TwistConstPtr msg) {
  data.code = 320;
  data.size = 8;
  data.cons_code = 1;
  data.cmd_data = msg->linear.x;
  input_->sendPacket((uint8_t*)&data, sizeof(data));

  data.code =325;
  data.size = 8;
  data.cons_code = 1;
  data.cmd_data = msg->linear.y;
  input_->sendPacket((uint8_t*)&data, sizeof(data));

  data.code = 321;
  data.size = 8;
  data.cons_code = 1;
  data.cmd_data = msg->angular.z;
  input_->sendPacket((uint8_t*)&data, sizeof(data));
}

void barrier_callback(std_msgs::Float64MultiArray msg){
  data_barrier.code = 322;
  data_barrier.size = 24;
  data_barrier.cons_code = 1;
  data_barrier.cmd_data1 = msg.data[0];
  data_barrier.cmd_data2 = msg.data[2];
  data_barrier.cmd_data3 = msg.data[3];
  input_->sendPacket((uint8_t*)&data_barrier, sizeof(data_barrier));
}


int main(int argc, char** argv) {
  ros::init(argc, argv, "ros2qnx");
  ros::NodeHandle nh;
  ros::NodeHandle private_nh("~");

  ros::Subscriber vel_sub = nh.subscribe("cmd_vel", 1, vel_callback);
  ros::Subscriber barrier_sub = nh.subscribe("/barrier_parking/barrier_distance", 1, barrier_callback);
  ros::Subscriber ultrasound_sub = nh.subscribe("/us_publisher/ultrasound_distance", 1, ultrasound_callback);
  //double vel_x_factor;
  //private_nh.param<double>("vel_x_factor", vel_x_factor, 1.0);

  input_.reset(new InputSocket(private_nh));

  ros::spin();

  return 0;
}
